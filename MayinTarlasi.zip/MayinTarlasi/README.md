# Mayın Tarlası
Java ile geliştirilen Mayın Tarlası.<br><b>Blog:</b> https://www.eminsaygi.com <br><b> Linkedin:</b> https://www.linkedin.com/in/eminsaygı

<b> Kullanılan Teknolojiler: </b>

Java SE  ile geliştirilmiştir.
Arayüz Java Swing ile geliştirilmiştir.


<b>Açılış ve Oyun hakkında bilgi</b>

<img src="https://github.com/eminsaygi/MayinTarlasi/blob/master/images/Açllış.PNG"></a>


<b>Oyun içinden Görüntüler</b>


<img src="https://github.com/eminsaygi/MayinTarlasi/blob/master/images/küçük%20resim.PNG"></a>

<img src="https://github.com/eminsaygi/MayinTarlasi/blob/master/images/geliştirici.PNG"></a>





<b>Menü Ve Özelleştirme </b>


<img src="https://github.com/eminsaygi/MayinTarlasi/blob/master/images/menü.PNG"></a>


<img src="https://github.com/eminsaygi/MayinTarlasi/blob/master/images/özelleştir.PNG"></a>
